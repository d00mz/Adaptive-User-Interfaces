/* don't forget to comment if necessary */
function functionNamesLikeThis(NewClass) {
	var variableNamesLikeThis = yes;
	this.NewClass = NewClass;
}
/* save JS files in lowercase > filenameslikethis.js */